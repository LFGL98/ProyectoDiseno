/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.*;

/**
 *
 * @author edder ruben
 */
public class AdminInsertarEmpleados {
     String URL= "jdbc:mysql://localhost:3306/refaccionaria";
            String USERNAME ="root";
            String PASSWORD ="12345";
            Connection connection=null;
             PreparedStatement insertEmpleados = null;
                ResultSet resultSet = null;
                public AdminInsertarEmpleados(){
                    try{
                     connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                     insertEmpleados = connection.prepareStatement("INSERT INTO empleados (ID,Nombre, Apellidos, Telefono, Password)"+"VALUES(?,?,?,?,?)");
                        }catch(SQLException e){e.printStackTrace();}
                    }
                    public int setEmpleados(String id, String nombre, String apellidos, String telefono, String password){
                    int result =0;
                    try{
                    insertEmpleados.setString(1, id);
                    insertEmpleados.setString(2, nombre);
                    insertEmpleados.setString(3, apellidos);
                    insertEmpleados.setString(4, telefono);
                    insertEmpleados.setString(5, password);
                    result = insertEmpleados.executeUpdate();
                                     
                            }catch(SQLException e){e.printStackTrace();}
return result;   
}
}
