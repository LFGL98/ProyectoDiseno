/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.*;

/**
 *
 * @author edder ruben
 */
public class BuscarClaveAgricultura {
    int bandera=1;
            String URL= "jdbc:mysql://localhost:3306/refaccionaria";
            String USERNAME ="root";
            String PASSWORD ="12345";
            Connection connection=null;   
            PreparedStatement selectProductos = null;
           
            ResultSet resultSet = null;
          public BuscarClaveAgricultura(){
            try{
             connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                selectProductos = connection.prepareStatement("SELECT ID, Nombre, Descripcion, Precio, Ubicacion,Palabra_Clave, ID_distribuidor FROM agricultura WHERE Palabra_Clave=?");
               }catch(SQLException e){
               e.printStackTrace();
                }
                }
            public ResultSet getProductos(String ub){
            try{
            selectProductos.setString(1, ub);
            resultSet = selectProductos.executeQuery();
            if(resultSet != null && resultSet.next()){
                    this.bandera=1;
                    }else{ 
                    this.bandera=0;
}
            }catch(SQLException e){
            e.printStackTrace();
                }
            return resultSet;
            }    
public int validarproducto(){
int ok=0;
if(bandera==1){
ok=1;
}else{
ok=0;
}
return ok;
}
}
