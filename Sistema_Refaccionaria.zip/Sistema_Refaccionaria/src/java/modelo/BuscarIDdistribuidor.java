/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.*;

/**
 *
 * @author edder ruben
 */
public class BuscarIDdistribuidor {
     int bandera3=0;
            String URL= "jdbc:mysql://localhost:3306/refaccionaria";
            String USERNAME ="root";
            String PASSWORD ="12345";
            Connection connection=null;
            PreparedStatement selectDistri = null;
            ResultSet resultSet = null;
            
            public BuscarIDdistribuidor(){
            try{
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                selectDistri = connection.prepareStatement("SELECT ID, Nombre, RFC, Telefono FROM distribuidores WHERE ID= ?");
                }catch(SQLException e){

                    }
                        
              }
              public ResultSet getDistribuidor(String ub){
                try{
                    selectDistri.setString(1, ub);
                    resultSet = selectDistri.executeQuery();
                    if(resultSet != null && resultSet.next()){
                    bandera3=1;
                    }else{
                    bandera3=0;
                      }
                    }catch(SQLException e){e.printStackTrace();}

                    return resultSet;
                    }
                    public int validardistri(){
                            int ok3=0;
                            if(bandera3==1){
                                ok3=1;
                                }else{
                                ok3=0;
                                }
                            return ok3;
                            }
}
