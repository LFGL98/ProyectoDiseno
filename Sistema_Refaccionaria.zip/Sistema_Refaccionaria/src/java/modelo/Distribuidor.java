
package modelo;

import java.sql.*;


/**
 *
 * @author edder ruben
 */
public class Distribuidor {
    String URL= "jdbc:mysql://localhost:3306/refaccionaria";
            String USERNAME ="root";
            String PASSWORD ="12345";
            Connection connection=null;
            String driver="com.mysql.jdbc.Driver";
            int contador=0;
            PreparedStatement select = null;   
            ResultSet resultSet = null;
            
            public Distribuidor(){
            try{
                Class.forName(this.driver);
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            select = connection.prepareStatement("SELECT ID, Nombre, RFC, Telefono FROM distribuidores");
            }catch(ClassNotFoundException | SQLException e){e.printStackTrace();}
            }
             public ResultSet get(){
                    try{    
                    
                    resultSet = select.executeQuery();
                    while(resultSet.next()){
                    this.contador++;
                    }
                    }catch(SQLException e){e.printStackTrace();}
                        return resultSet;
                        }
             public int conteo(){
             
                 return this.contador;
             }
}
