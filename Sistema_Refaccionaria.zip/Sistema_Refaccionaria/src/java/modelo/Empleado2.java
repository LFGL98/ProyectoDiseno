/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.*;

/**
 *
 * @author edder ruben
 */
public class Empleado2 {
     
            String URL= "jdbc:mysql://localhost:3306/refaccionaria";
            String USERNAME ="root";
            String PASSWORD ="12345";
            Connection connection=null;
         String driver="com.mysql.jdbc.Driver";
            PreparedStatement selectEmpleados2 = null;
           
            
            ResultSet resultSet2 = null;
            public Empleado2(){
            try{
                Class.forName(driver);
                connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                selectEmpleados2 = connection.prepareStatement("SELECT ID, Nombre,Apellidos, Telefono FROM empleados");
              
                }catch(ClassNotFoundException | SQLException e){
                e.printStackTrace();
}
                       }
public ResultSet getEmpleados2(){
try{

    
    
    resultSet2 = selectEmpleados2.executeQuery();
  

}catch(SQLException e){
e.printStackTrace();
}

return resultSet2;
}
}
