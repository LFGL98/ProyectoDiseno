/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.*;

/**
 *
 * @author edder ruben
 */
public class AdminDistribuidores{
                int bandera01=0;
                String URL= "jdbc:mysql://localhost:3306/refaccionaria";
            String USERNAME ="root";
            String PASSWORD ="12345";
            String driver="com.mysql.jdbc.Driver";
            Connection connection=null;   
            PreparedStatement selectDistribuidor0 = null;
           
            ResultSet resultSet01 = null;
         public AdminDistribuidores(){
         try{
             Class.forName(driver);
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            selectDistribuidor0 = connection.prepareStatement("SELECT ID, Nombre, RFC, Telefono FROM distribuidores");
            }catch(ClassNotFoundException | SQLException e){e.printStackTrace();}
                } 
                public ResultSet getDistribuidor2(){
                try{
    resultSet01= selectDistribuidor0.executeQuery();
                }catch(SQLException e){e.printStackTrace();}
                return resultSet01;
                    }
                    }