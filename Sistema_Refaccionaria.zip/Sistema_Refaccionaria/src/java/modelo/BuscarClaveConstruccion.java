/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.*;

/**
 *
 * @author edder ruben
 */
public class BuscarClaveConstruccion{
               int bandera5=0;
                  String URL= "jdbc:mysql://localhost:3306/refaccionaria";
            String USERNAME ="root";
            String PASSWORD ="12345";
            Connection connection=null;
         
            PreparedStatement selectconstruccion = null;   
            ResultSet resultSet5 = null;
                        
              public BuscarClaveConstruccion(){
                    try{
                    connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                    selectconstruccion = connection.prepareStatement("SELECT ID, Nombre, Descripcion, Precio, Ubicacion, Palabra_Clave, ID_distribuidor FROM construccion WHERE Palabra_Clave= ?");
                    }catch(SQLException e){e.printStackTrace();}
                    }
                    public ResultSet getConstruccion(String ub2){
                    try{    
                    selectconstruccion.setString(1, ub2);
                    resultSet5 = selectconstruccion.executeQuery();
                    if(resultSet5 != null && resultSet5.next()){
                    this.bandera5=1;
                       }else{
                        this.bandera5=0;
                         }
                    }catch(SQLException e){e.printStackTrace();}
                        return resultSet5;
                        }
                        public int validarconstruccion(){
                            int ok6=0;
                         if(bandera5==1){
                            ok6=1;
                                }else{
                                  ok6=0;  
                                    } 
                                    return ok6;
                            }
                    }