/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author edder ruben
 */
public class Conexion {
    Connection cnn;
    PreparedStatement state;
    ResultSet res;
    boolean bandera=false;
  String URL= "jdbc:mysql://localhost:3306/refaccionaria";
            String USERNAME ="root";
            String PASSWORD ="12345";
    
   public Conexion(){
       
        try {
            Class.forName("com.mysql.jdbc.Driver");
        cnn=DriverManager.getConnection(URL,USERNAME,PASSWORD);
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
   
   public ResultSet get2(String id, String pass){
     
       try {
            String sql ="SELECT ID FROM empleados WHERE id=? AND Password=?";
             state = cnn.prepareStatement(sql);
            state.setString(1, id);
            state.setString(2, pass);
            res= state.executeQuery();
            
         
          if(res.next()){
          this.bandera=true;
          }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return res;
   }
   public boolean get(){
   
   return bandera;
   }
}
