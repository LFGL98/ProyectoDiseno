/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.*;

/**
 *
 * @author edder ruben
 */
public class BuscarIDempleados {
      int bandera3=0;
            String URL= "jdbc:mysql://localhost:3306/refaccionaria";
            String USERNAME ="root";
            String PASSWORD ="12345";
            String driver="com.mysql.jdbc.Driver";
            Connection connection=null;
            PreparedStatement select = null;
            ResultSet resultSet = null;
            
            public BuscarIDempleados(){
            try{
                Class.forName(driver);
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                select = connection.prepareStatement("SELECT ID, Nombre, Apellidos, Telefono FROM empleados WHERE ID like ?");
                }catch(ClassNotFoundException | SQLException e){

                    }
                        
              }
              public ResultSet get(String ub){
                try{
                    select.setString(1, ub);
                    resultSet = select.executeQuery();
                    if(resultSet != null && resultSet.next()){
                    bandera3=1;
                    }else{
                    bandera3=0;
                      }
                    }catch(SQLException e){e.printStackTrace();}

                    return resultSet;
                    }
                    public int validar(){
                            int ok3=0;
                            if(bandera3==1){
                                ok3=1;
                                }else{
                                ok3=0;
                                }
                            return ok3;
                            }
}
