/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.*;

/**
 *
 * @author edder ruben
 */
public class BuscarClaveAutos {
                 int bandera3=0;
            String URL= "jdbc:mysql://localhost:3306/refaccionaria";
            String USERNAME ="root";
            String PASSWORD ="12345";
            Connection connection=null;
            PreparedStatement selectAutos = null;
            ResultSet resultSet = null;
            
            public BuscarClaveAutos(){
            try{
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                selectAutos = connection.prepareStatement("SELECT ID, Nombre, Descripcion, Precio, Ubicacion,Palabra_Clave, ID_distribuidor FROM automoviles WHERE Palabra_Clave= ?");
                }catch(SQLException e){

                    }
                        
              }
              public ResultSet getAutos(String ub){
                try{
                    selectAutos.setString(1, ub);
                    resultSet = selectAutos.executeQuery();
                    if(resultSet != null && resultSet.next()){
                    bandera3=1;
                    }else{
                    bandera3=0;
                      }
                    }catch(SQLException e){e.printStackTrace();}

                    return resultSet;
                    }
                    public int validarauto(){
                            int ok3=0;
                            if(bandera3==1){
                                ok3=1;
                                }else{
                                ok3=0;
                                }
                            return ok3;
                            }
}
