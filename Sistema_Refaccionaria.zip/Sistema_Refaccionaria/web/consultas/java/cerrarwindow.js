function closeWin() {
  window.close();
}