/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.*;

/**
 *
 * @author edder ruben
 */
public class Agricultura2 {
     String URL= "jdbc:mysql://localhost:3306/refaccionaria";
            String USERNAME ="root";
            String PASSWORD ="12345";
            String driver="com.mysql.jdbc.Driver";
            Connection connection=null;   
            PreparedStatement selectProductos2 = null;
           
            ResultSet resultSet2 = null;
          public Agricultura2(){
            try{
                Class.forName(driver);
             connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                selectProductos2 = connection.prepareStatement("SELECT ID, Nombre, Descripcion, Precio, Ubicacion,Palabra_Clave, ID_distribuidor FROM agricultura");
               }catch(ClassNotFoundException | SQLException e){
               e.printStackTrace();
                }
                }
            public ResultSet getProductos2(){
            try{
            
            resultSet2 = selectProductos2.executeQuery();
      
            }catch(SQLException e){
            e.printStackTrace();
                }
            return resultSet2;
            }    
}
