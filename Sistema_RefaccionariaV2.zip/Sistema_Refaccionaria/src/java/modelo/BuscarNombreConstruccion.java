/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author edder ruben
 */
public class BuscarNombreConstruccion {
     int bandera3=0;
            String URL= "jdbc:mysql://localhost:3306/refaccionaria";
            String USERNAME ="root";
            String PASSWORD ="12345";
             String driver="com.mysql.jdbc.Driver";
            Connection connection=null;
            PreparedStatement select = null;
            ResultSet resultSet = null;
            
            public BuscarNombreConstruccion(){
            try{
                Class.forName(driver);
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                select = connection.prepareStatement("SELECT ID, Nombre, Descripcion, Precio, Ubicacion,Palabra_Clave, ID_distribuidor FROM construccion WHERE Nombre=?");
                }catch(ClassNotFoundException | SQLException e){

                    }
                        
              }
              public ResultSet get(String id){
                try{
                    select.setString(1, id);
                    resultSet = select.executeQuery();
                    if(resultSet != null && resultSet.next()){
                    bandera3=1;
                    }else{
                    bandera3=0;
                      }
                    }catch(SQLException e){e.printStackTrace();}

                    return resultSet;
                    }
                    public int validar(){
                            int ok3=0;
                            if(bandera3==1){
                                ok3=1;
                                }else{
                                ok3=0;
                                }
                            return ok3;
                            }
}
