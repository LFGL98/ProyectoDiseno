/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.*;

/**
 *
 * @author edder ruben
 */
 public class EliminarEmpleado {

                                    int result = 0;
                                    String URL = "jdbc:mysql://localhost:3306/refaccionaria";
                                    String USERNAME = "root";
                                    String PASSWORD = "12345";
                                    String driver = "com.mysql.jdbc.Driver";
                                    Connection connection = null;
                                    PreparedStatement deleteEmpleado = null;

                                    public EliminarEmpleado() {
                                        try {
                                            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                                            deleteEmpleado = connection.prepareStatement("DELETE FROM empleados Where ID=?");
                                        } catch (SQLException e) {
                                            e.printStackTrace();
                                        }
                                    }

                                    public int eliminar(String id) {

                                        try {
                                            deleteEmpleado.setString(1, id);
                                            int row = deleteEmpleado.executeUpdate();

                                            if (row != 0) {
                                                this.result = 1;
                                            } else {
                                                this.result = 0;
                                            }
                                        } catch (SQLException e) {
                                            e.printStackTrace();
                                        }

                                        return this.result;
                                    }
                                }
