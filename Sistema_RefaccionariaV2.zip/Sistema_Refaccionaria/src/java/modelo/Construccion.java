/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.*;


/**
 *
 * @author edder ruben
 */
public class Construccion{
    String URL= "jdbc:mysql://localhost:3306/refaccionaria";
            String USERNAME ="root";
            String PASSWORD ="12345";
            Connection connection=null;
            String driver="com.mysql.jdbc.Driver";
            int contador=0;
            PreparedStatement select = null;   
            ResultSet resultSet = null;
            
            public Construccion() throws ClassNotFoundException{
            try{
                Class.forName(this.driver);
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            select = connection.prepareStatement("SELECT ID FROM construccion");
            }catch(SQLException e){e.printStackTrace();}
            }
             public ResultSet get(){
                    try{    
                    
                    resultSet = select.executeQuery();
                    while(resultSet.next()){
                    this.contador++;
                    }
                    }catch(SQLException e){e.printStackTrace();}
                        return resultSet;
                        }
             public int conteo(){
             
                 return this.contador;
             }
}
