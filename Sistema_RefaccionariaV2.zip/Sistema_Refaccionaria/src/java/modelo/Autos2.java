/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.*;

/**
 *
 * @author edder ruben
 */
public class Autos2 {
    
            String URL= "jdbc:mysql://localhost:3306/refaccionaria";
            String USERNAME ="root";
            String PASSWORD ="12345";
            String driver="com.mysql.jdbc.Driver";
            Connection connection=null;
            PreparedStatement selectAutos3 = null;
            ResultSet resultSet3 = null;
            
            public Autos2(){
            try{
                Class.forName(driver);
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                selectAutos3 = connection.prepareStatement("SELECT ID, Nombre, Descripcion, Precio, Ubicacion,Palabra_Clave, ID_distribuidor FROM automoviles order by ID asc");
                }catch(ClassNotFoundException | SQLException e){

                    }
                        
              }
              public ResultSet getAutos2(){
                try{
                    
                    resultSet3= selectAutos3.executeQuery();
                   
                    }catch(SQLException e){e.printStackTrace();}

                    return resultSet3;
                    }    
}
