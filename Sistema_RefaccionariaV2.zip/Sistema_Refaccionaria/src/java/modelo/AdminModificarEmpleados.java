/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.*;

/**
 *
 * @author edder ruben
 */
 public class AdminModificarEmpleados {

                                    int bandera = 0;
                                    String URL = "jdbc:mysql://localhost:3306/refaccionaria";
                                    String USERNAME = "root";
                                    String PASSWORD = "12345";
                                    String driver = "com.mysql.jdbc.Driver";
                                    Connection connection = null;

                                    int resultSet0 = 0;

                                    public AdminModificarEmpleados() {
                                        try {

                                            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);

                                        } catch (SQLException e) {
                                            e.printStackTrace();
                                        }
                                    }

                                    public int setEmpleados(String id, String nombre, String apellidos, String telefono, String pass) {
                                        try {

                                            String sql = "UPDATE empleados SET Nombre='" + nombre + "', Apellidos='" + apellidos + "', Telefono='" + telefono + "', Password='" + pass + "'  Where ID= '" + id + "'";
                                            Statement sql2 = connection.createStatement();

                                            this.bandera = sql2.executeUpdate(sql);

                                        } catch (SQLException e) {
                                            e.printStackTrace();
                                        }
                                        return this.bandera;
                                    }

                                }
