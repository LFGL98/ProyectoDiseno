/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.*;

/**
 *
 * @author edder ruben
 */
public class AdminInsertarDistribuidores {
   String URL= "jdbc:mysql://localhost:3306/refaccionaria";
            String USERNAME ="root";
            String PASSWORD ="12345";
            Connection connection=null;
             PreparedStatement insert = null;
                ResultSet resultSet = null;
                public AdminInsertarDistribuidores(){
                    try{
                     connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                     insert= connection.prepareStatement("INSERT INTO distribuidores (ID,Nombre, RFC,Telefono)"+"VALUES(?,?,?,?)");
                        }catch(SQLException e){e.printStackTrace();}
                    }
                    public int setEmpleados(String id, String nombre, String rfc, String telefono){
                    int result =0;
                    try{
                    insert.setString(1, id);
                    insert.setString(2, nombre);
                    insert.setString(3, rfc);
                    insert.setString(4, telefono);
              
                    result = insert.executeUpdate();
                                     
                            }catch(SQLException e){e.printStackTrace();}
return result;   
}   
}
