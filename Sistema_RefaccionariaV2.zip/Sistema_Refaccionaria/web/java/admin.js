function modificar_empleado(){
    document.getElementById("operaciones").style.display="none";
    document.getElementById("modificar_empleado").style.display="";
    
}
function modificar_empleado2(){
    document.getElementById("modificar_empleado").style.display="none";
    document.getElementById("operaciones").style.display="";
}
function modificar_distribuidor(){
    document.getElementById("operaciones").style.display="none";
    document.getElementById("modificar_distribuidor").style.display="";
    
}
function modificar_distribuidor2(){
    document.getElementById("modificar_distribuidor").style.display="none";
    document.getElementById("operaciones").style.display="";
}
function modificar_agricultura(){
    document.getElementById("operaciones").style.display="none";
    document.getElementById("modificar_agricultura").style.display="";
    
}
function modificar_agricultura2(){
    document.getElementById("modificar_agricultura").style.display="none";
    document.getElementById("operaciones").style.display="";
}
function modificar_automoviles(){
    document.getElementById("operaciones").style.display="none";
    document.getElementById("modificar_empleado").style.display="";
    
}
function modificar_automoviles2(){
    document.getElementById("modificar_automoviles").style.display="none";
    document.getElementById("operaciones").style.display="";
}
function modificar_construccion(){
    document.getElementById("operaciones").style.display="none";
    document.getElementById("modificar_construccion").style.display="";
    
}
function modificar_construccion2(){
    document.getElementById("modificar_construccion").style.display="none";
    document.getElementById("operaciones").style.display="";
}
function eliminar_empleado(){
    document.getElementById("operaciones").style.display="none";
    document.getElementById("eliminar_empleado").style.display="";
    
}
function eliminar_empleado2(){
    document.getElementById("eliminar_empleado").style.display="none";
    document.getElementById("operaciones").style.display="";
}
function eliminar_distribuidor(){
    document.getElementById("operaciones").style.display="none";
    document.getElementById("eliminar_distribuidor").style.display="";
    
}
function eliminar_distribuidor2(){
    document.getElementById("eliminar_distribuidor").style.display="none";
    document.getElementById("operaciones").style.display="";
}
function eliminar_agricultura(){
    document.getElementById("operaciones").style.display="none";
    document.getElementById("eliminar_agricultura").style.display="";
    
}
function eliminar_agricultura2(){
    document.getElementById("eliminar_agricultura").style.display="none";
    document.getElementById("operaciones").style.display="";
}
function eliminar_automoviles(){
    document.getElementById("operaciones").style.display="none";
    document.getElementById("eliminar_automoviles").style.display="";
    
}
function eliminar_automoviles2(){
    document.getElementById("eliminar_automoviles").style.display="none";
    document.getElementById("operaciones").style.display="";
}
function eliminar_construccion(){
     document.getElementById("operaciones").style.display="none";
    document.getElementById("eliminar_construccion").style.display="";
   
}
function eliminar_construccion2(){
    document.getElementById("eliminar_construccion").style.display="none";
    document.getElementById("operaciones").style.display="";
}
function insertar_empleado(){
    document.getElementById("operaciones").style.display="none";
    document.getElementById("insertar_empleado").style.display="";
    
}
function insertar_empleado2(){
    document.getElementById("insertar_empleado").style.display="none";
    document.getElementById("operaciones").style.display="";
}
function insertar_agricultura(){
    document.getElementById("operaciones").style.display="none";
    document.getElementById("insertar_agricultura").style.display="";
    
}
function insertar_agricultura2(){
    document.getElementById("insertar_agricultura").style.display="none";
    document.getElementById("operaciones").style.display="";
}
function insertar_automoviles(){
    document.getElementById("operaciones").style.display="none";
    document.getElementById("insertar_automoviles").style.display="";
    
}
function insertar_automoviles2(){
    document.getElementById("insertar_automoviles").style.display="none";
    document.getElementById("operaciones").style.display="";
}
function insertar_construccion(){
    document.getElementById("operaciones").style.display="none";
    document.getElementById("insertar_construccion").style.display="";
    
}
function insertar_construccion2(){
    document.getElementById("insertar_construccion").style.display="none";
    document.getElementById("operaciones").style.display="";
}
function insertar_distribuidor(){
    document.getElementById("operaciones").style.display="none";
    document.getElementById("insertar_distribuidor").style.display="";
    
}
function insertar_distribuidor2(){
    document.getElementById("insertar_distribuidor").style.display="none";
    document.getElementById("operaciones").style.display="";
}