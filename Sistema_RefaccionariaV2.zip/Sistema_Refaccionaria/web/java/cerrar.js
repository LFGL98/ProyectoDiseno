/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function IDEMPLEADOS(){
    document.getElementById("ID").style.display="";
    document.getElementById("empleados").style.display="none";
}


function IDEMPLEADOS2(){
    document.getElementById("ID").style.display="none";
    document.getElementById("empleados").style.display="";
}


function NOMBREEMPLEADOS(){
    document.getElementById("NOMBRE").style.display="";
    document.getElementById("empleados").style.display="none";
    
}



function NOMBREEMPLEADOS2(){
    document.getElementById("NOMBRE").style.display="none";
    document.getElementById("empleados").style.display="";
    
}



function IDDISTRIBUIDOR(){
    document.getElementById("IDDISTRIBUIDOR").style.display=""
    document.getElementById("distribuidores").style.display="none";

}

function IDDISTRIBUIDOR2(){
    document.getElementById("IDDISTRIBUIDOR").style.display="none"
    document.getElementById("distribuidores").style.display="";
    
}

function NOMBREDISTRIBUIDOR(){
    document.getElementById("NOMBREDISTRIBUIDOR").style.display=""
    document.getElementById("distribuidores").style.display="none";

}

function NOMBREDISTRIBUIDOR2(){
    document.getElementById("NOMBREDISTRIBUIDOR").style.display="none"
    document.getElementById("distribuidores").style.display="";
    
}

function IDAGRICULTURA(){
    document.getElementById("id_agricultura").style.display="";
    document.getElementById("agricultura").style.display="none"; 
}
function IDAGRICULTURA2(){
    document.getElementById("id_agricultura").style.display="none";
    document.getElementById("agricultura").style.display="";
    
}

function NOMBREAGRICULTURA(){
    document.getElementById("agricultura").style.display="none";
    document.getElementById("nombre_agricultura").style.display="";
}
function NOMBREAGRICULTURA2(){
    document.getElementById("nombre_agricultura").style.display="none";
    document.getElementById("agricultura").style.display="";
}
function PALABRAAGRICULTURA(){
    document.getElementById("agricultura").style.display="none";
    document.getElementById("palabra_agricultura").style.display="";
}
function PALABRAAGRICULTURA2(){
    document.getElementById("palabra_agricultura").style.display="none";
    document.getElementById("agricultura").style.display="";
    
}


function IDCONSTRUCCION(){
    document.getElementById("id_construccion").style.display="";
    document.getElementById("construccion").style.display="none"; 
}
function IDCONSTRUCCION2(){
    document.getElementById("id_construccion").style.display="none";
    document.getElementById("construccion").style.display="";
    
}

function NOMBRECONSTRUCCION(){
    document.getElementById("construccion").style.display="none";
    document.getElementById("nombre_construccion").style.display="";
}
function NOMBRECONSTRUCCION2(){
    document.getElementById("nombre_construccion").style.display="none";
    document.getElementById("construccion").style.display="";
}
function PALABRACONSTRUCCION(){
    document.getElementById("construccion").style.display="none";
    document.getElementById("palabra_construccion").style.display="";
}
function PALABRACONSTRUCCION2(){
    document.getElementById("palabra_construccion").style.display="none";
    document.getElementById("construccion").style.display="";
    
}

function IDAUTOMOVILES(){
    document.getElementById("id_automoviles").style.display="";
    document.getElementById("automoviles").style.display="none"; 
}
function IDAUTOMOVILES2(){
    document.getElementById("id_automoviles").style.display="none";
    document.getElementById("automoviles").style.display="";
    
}

function NOMBREAUTOMOVILES(){
    document.getElementById("automoviles").style.display="none";
    document.getElementById("nombre_automoviles").style.display="";
}
function NOMBREAUTOMOVILES2(){
    document.getElementById("nombre_automoviles").style.display="none";
    document.getElementById("automoviles").style.display="";
}
function PALABRAAUTOMOVILES(){
    document.getElementById("automoviles").style.display="none";
    document.getElementById("palabra_automoviles").style.display="";
}
function PALABRAAUTOMOVILES2(){
    document.getElementById("palabra_automoviles").style.display="none";
    document.getElementById("automoviles").style.display="";
    
}