function modificar_agricultura(){
    document.getElementById("agricultura").style.display="none";
    document.getElementById("modificar_agricultura").style.display="";
    
}
function modificar_agricultura2(){
    document.getElementById("modificar_agricultura").style.display="none";
    document.getElementById("agricultura").style.display="";
}
function modificar_construccion(){
    document.getElementById("construccion").style.display="none";
    document.getElementById("modificar_construccion").style.display="";
    
}
function modificar_construccion2(){
    document.getElementById("modificar_construccion").style.display="none";
    document.getElementById("construccion").style.display="";
}
function modificar_automoviles(){
    document.getElementById("automoviles").style.display="none";
    document.getElementById("modificar_automoviles").style.display="";
    
}
function modificar_automoviles2(){
    document.getElementById("modificar_automoviles").style.display="none";
    document.getElementById("automoviles").style.display="";
}