function modificar_automoviles(){
    document.getElementById("operaciones").style.display="none";
    document.getElementById("modificar_automoviles").style.display="";
    
}
function modificar_automoviles2(){
    document.getElementById("modificar_automoviles").style.display="none";
    document.getElementById("operaciones").style.display="";
}