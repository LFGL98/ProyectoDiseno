/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.*;

/**
 *
 * @author edder ruben
 */
public class AdminInsertarAgricultura {
     String URL= "jdbc:mysql://localhost:3306/refaccionaria";
            String USERNAME ="root";
            String PASSWORD ="12345";
             String driver = "com.mysql.jdbc.Driver";
            Connection connection=null;
             PreparedStatement insert = null;
                ResultSet resultSet = null;
                public AdminInsertarAgricultura(){
                    try{
                        Class.forName(driver);
                     connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                     insert= connection.prepareStatement("INSERT INTO agricultura (ID,Nombre, Descripcion, Precio, Ubicacion, Palabra_Clave, ID_distribuidor)"+"VALUES(?,?,?,?,?,?,?)");
                        }catch(ClassNotFoundException | SQLException e){e.printStackTrace();}
                    }
                    public int setEmpleados(String id, String nombre, String descripcion, Float precio, String ubicacion, String palabra_clave, String distribuidor){
                    int result =0;
                    try{
                    insert.setString(1, id);
                    insert.setString(2, nombre);
                    insert.setString(3, descripcion);
                    insert.setFloat(4, precio);
                    insert.setString(5, ubicacion);
                    insert.setString(6, palabra_clave);
                    insert.setString(7, distribuidor);
                    result = insert.executeUpdate();
                         
                            }catch(SQLException e){e.printStackTrace();}
return result;   
}
}
