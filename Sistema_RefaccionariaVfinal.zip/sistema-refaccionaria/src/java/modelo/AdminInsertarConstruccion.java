/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.*;

/**
 *
 * @author edder ruben
 */
 public class AdminInsertarConstruccion{
         String URL= "jdbc:mysql://localhost:3306/refaccionaria";
            String USERNAME ="root";
            String PASSWORD ="12345";
             String driver = "com.mysql.jdbc.Driver";
            Connection connection=null;
             PreparedStatement insertConstruccion = null;
                ResultSet resultSet = null;
                public AdminInsertarConstruccion(){
                    try{
                        Class.forName(driver);
                     connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                     insertConstruccion = connection.prepareStatement("INSERT INTO construccion (ID,Nombre, Descripcion, Precio, Ubicacion, Palabra_Clave, ID_distribuidor)"+"VALUES(?,?,?,?,?,?,?)");
                        }catch(ClassNotFoundException | SQLException e){e.printStackTrace();}
                    }
                    public int setEmpleados(String id, String nombre, String descripcion, Float precio, String ubicacion, String palabra_clave, String distribuidor){
                    int result =0;
                    try{
                    insertConstruccion.setString(1, id);
                    insertConstruccion.setString(2, nombre);
                    insertConstruccion.setString(3, descripcion);
                    insertConstruccion.setFloat(4, precio);
                    insertConstruccion.setString(5, ubicacion);
                    insertConstruccion.setString(6, palabra_clave);
                    insertConstruccion.setString(7, distribuidor);
                    result = insertConstruccion.executeUpdate();
                             
                            }catch(SQLException e){e.printStackTrace();}
return result;   
}
}