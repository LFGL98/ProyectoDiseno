/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.*;

/**
 *
 * @author edder ruben
 */
                public class AdminModificarConstruccion {
    int bandera10=0;
    String URL= "jdbc:mysql://localhost:3306/refaccionaria";
            String USERNAME ="root";
            String PASSWORD ="12345";
             String driver = "com.mysql.jdbc.Driver";
            Connection connection=null;
            
            public AdminModificarConstruccion(){
            try{
                Class.forName(driver);
             connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            
                }catch(ClassNotFoundException | SQLException e){e.printStackTrace();}
            
            }
            public int getResults(String id, String nombre, String descripcion, Float precio, String ubicacion, String palabra_clave, String distribuidor){
            try{
          String sql="UPDATE construccion SET Nombre='"+nombre+"',Descripcion='"+descripcion+"', Precio='"+precio+"', Ubicacion='"+ubicacion+"', Palabra_Clave='"+palabra_clave+"', ID_distribuidor='"+distribuidor+"' WHERE ID='"+id+"'";
          Statement sql1 = connection.createStatement();
          
          int rowCON= sql1.executeUpdate(sql);
            if(rowCON!=0){
                this.bandera10=1;
                }else{this.bandera10=0;}
            
            }catch(SQLException e){e.printStackTrace();}
                
                return bandera10;
            }
}