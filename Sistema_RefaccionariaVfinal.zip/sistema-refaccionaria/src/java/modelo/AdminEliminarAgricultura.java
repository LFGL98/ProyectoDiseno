/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.*;

/**
 *
 * @author edder ruben
 */
public class AdminEliminarAgricultura {
      int result=0;
            String URL= "jdbc:mysql://localhost:3306/refaccionaria";
            String USERNAME ="root";
            String PASSWORD ="12345";
            String driver ="com.mysql.jdbc.Driver";
            Connection connection=null;   
            PreparedStatement delete = null;
            public AdminEliminarAgricultura(){
            try{
                Class.forName(driver);
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            delete = connection.prepareStatement("DELETE FROM agricultura WHERE ID=?");
            }catch(ClassNotFoundException | SQLException e){e.printStackTrace();}
            }
            public int getResult(String id){
            try{
            delete.setString(1, id);
            int row = delete.executeUpdate();
            if(row!=0){
            this.result=1;
            }else{
            this.result=0;
            }
            
            }catch(SQLException e){e.printStackTrace();}
                return result;
            }
}
