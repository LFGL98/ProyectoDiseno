/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.*;

/**
 *
 * @author edder ruben
 */
public class Construccion2{
              
                  String URL= "jdbc:mysql://localhost:3306/refaccionaria";
            String USERNAME ="root";
            String PASSWORD ="12345";
            String driver="com.mysql.jdbc.Driver";
            Connection connection=null;
         
            PreparedStatement selectconstruccion2 = null;   
            ResultSet resultSet6 = null;
                        
              public Construccion2(){
                    try{
                        Class.forName(driver);
                    connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                    selectconstruccion2 = connection.prepareStatement("SELECT ID, Nombre, Descripcion, Precio, Ubicacion, Palabra_Clave, ID_distribuidor FROM construccion");
                    }catch(ClassNotFoundException | SQLException e){e.printStackTrace();}
                    }
                    public ResultSet getConstruccion2(){
                    try{    
                    
                    resultSet6 = selectconstruccion2.executeQuery();
                   
                    }catch(SQLException e){e.printStackTrace();}
                        return resultSet6;
                        }
                       
                    }